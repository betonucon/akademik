<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Beasiswadaftar extends Model
{
    protected $table = 'beasiswa_daftar';
    public $timestamps = false;
}
