<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tahunajaran extends Model
{
    protected $table = 'tahun_ajaran';
    public $timestamps = false;
}
