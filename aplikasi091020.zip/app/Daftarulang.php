<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daftarulang extends Model
{
    protected $table = 'daftar_ulang';
    public $timestamps = false;
}
