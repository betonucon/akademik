<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembayarandaftar extends Model
{
    protected $table = 'pembayaran_daftar';
    public $timestamps = false;
}
