<?php

function barcoderidergambar($id,$w,$h){
    $d = new Milon\Barcode\DNS2D();
    $d->setStorPath(__DIR__.'/cache/');
    return '<img style="width:40%;margin-left:29%;display:block" src="data:image/png;base64,'.$d->getBarcodePNG($id, 'QRCODE'). '" alt="barcode"   />';
}


?>